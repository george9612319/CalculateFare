package com.example.CaculateFare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaculateFareApplicationTests {

	@Test
	void contextLoads() {
	}

}
